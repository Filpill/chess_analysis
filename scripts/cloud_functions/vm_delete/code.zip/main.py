import re
import json
import base64
import logging
import functions_framework
from googleapiclient import discovery

PROJECT = "checkmate-453316"
ZONE = "europe-west1-c"

def delete_vm(project, zone, instance_name):
    compute = discovery.build('compute', 'v1')
    request = compute.instances().delete(
        project=project,
        zone=zone,
        instance=instance_name
    )
    response = request.execute()
    logging.info(f"Delete request sent for VM: {instance_name}")
    return response

@functions_framework.cloud_event
def pubsub_handler(cloud_event):
    # Decode the incoming Pub/Sub message
    logging.info(f"RAW cloud event: {cloud_event}")

    try:
        # Get base64-encoded data from Pub/Sub message via CloudEvent
        message_data = cloud_event.data["message"]["data"]
        payload = base64.b64decode(message_data).decode("utf-8")
        logging.info(f"Decoded Pub/Sub message payload: {payload}")

        # Parse the JSON log entry
        log_entry = json.loads(payload)

        # Extract the VM name from the log's jsonPayload._HOSTNAME
        vm_name = log_entry.get("jsonPayload", {}).get("_HOSTNAME")
        if not vm_name:
            logging.error("No _HOSTNAME found in log entry.")
            return

        logging.warning(f"Deleting VM: {vm_name}")
        delete_vm(PROJECT, ZONE, vm_name)

    except Exception as e:
        logging.exception(f"Error handling CloudEvent: {e}")
